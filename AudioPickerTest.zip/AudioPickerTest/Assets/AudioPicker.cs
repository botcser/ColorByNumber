﻿using System.Collections;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

namespace Assets
{
    public class AudioPicker : MonoBehaviour
    {
        public AudioSource AudioSource;
        public Text PathText;
        public string Path = @"D:\Downloads\SummerChallenge.mp3";

        public void Start()
        {
            PathText.text = Path;
        }

        public void Pick()
        {
            var mp3FileType = NativeFilePicker.ConvertExtensionToFileType("mp3");
            var permission = NativeFilePicker.PickFile(path =>
            {
                if (path == null)
                {
                    PathText.text = "Operation cancelled";
                }
                else
                {
                    Path = path;
                    PathText.text = Path;
                }
            }, new string[] { mp3FileType });

            PathText.text = "permission = " + permission;
        }

        public void Play()
        {
            StartCoroutine(GetAudioClip());
        }

        private IEnumerator GetAudioClip()
        {
            using (var www = UnityWebRequestMultimedia.GetAudioClip($"file://{Path}", AudioType.MPEG))
            {
                yield return www.SendWebRequest();

                if (www.isHttpError || www.isNetworkError)
                {
                    Debug.Log(www.error);
                }
                else
                {
                    var clip = DownloadHandlerAudioClip.GetContent(www);

                    AudioSource.PlayOneShot(clip);
                }
            }
        }
    }
}
﻿using UnityEngine;

namespace Assets
{
    public class Example : MonoBehaviour
    {
        public void Start()
        {
            var dummyText = (TextAsset) Resources.Load("DummyText");

            Debug.Log(dummyText.text);

            var dummyBinary = (TextAsset)Resources.Load("DummyBinary");

            Debug.Log(dummyBinary.bytes.Length);
        }
    }
}